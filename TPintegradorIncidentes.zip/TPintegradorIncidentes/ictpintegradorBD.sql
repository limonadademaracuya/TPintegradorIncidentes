DROP DATABASE IF EXISTS ictpintegradorBD;
CREATE DATABASE IF NOT EXISTS ictpintegradorBD;
USE ictpintegradorBD;

-- Tabla User
CREATE TABLE Users (
  id INT auto_increment PRIMARY KEY,
  username VARCHAR(100),
  email VARCHAR(255),
  password VARCHAR(255),
  role varchar(50)
);

-- Tabla Product
CREATE TABLE Products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255),
  description TEXT,
  price DOUBLE,
  user_id INT,
  CONSTRAINT fk_products_user FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- Tabla Comment
CREATE TABLE Comments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  user_id INT NOT NULL,
  content TEXT,
  created_at VARCHAR(50),
  CONSTRAINT fk_comments_product FOREIGN KEY (product_id) REFERENCES Products(id),
  CONSTRAINT fk_comments_user FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- Inserts ejemplo User
INSERT INTO Users (id, username, email, password, role) VALUES
(1, 'juan', 'juan@example.com', 'hola1234',"admin"),
(2, 'maria', 'maria@example.com', 'hola1234',"moderador"),
(3, 'carmen', 'carmen@example.com', 'hola1234',"usuario");

-- Inserts ejemplo Product
INSERT INTO Products (id, name, description, price, user_id) VALUES
(1, 'Laptop', 'Laptop gamer con procesador i7', 1200.50, 1),
(2, 'Mouse', 'Mouse inalámbrico', 25.99, 2),
(3, 'Teclado', 'Teclado mecánico RGB', 75.00, 3);

-- Inserts ejemplo Comment
INSERT INTO Comments (id, product_id, user_id, content, created_at) VALUES
(1, 1, 2, 'Excelente producto, muy rápido.', '2025-07-10 15:30'),
(2, 2, 1, 'El mouse dura bastante la batería.', '2025-07-09 12:00'),
(3, 3, 3, 'El teclado tiene buen tacto.', '2025-07-08 18:45');

select * from users;
